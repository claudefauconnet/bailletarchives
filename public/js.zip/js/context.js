var context = {
    dataModel :{},
    currentTable: "",
    currentRecord:{},
    currentLinkedTable: "",
    dataTables: {},
    currentTabIndex:0,
    currentCriteria:[],
    currentVersementInfos:{},
    currentListQueries:{},

    hiddenMainDivContent:{graph:"",table:""},
}